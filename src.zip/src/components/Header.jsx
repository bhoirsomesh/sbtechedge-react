import { Link } from 'react-router-dom';
function Header() {
    return (
      <header className="navbar">
        <div className="navbar-container">
          <a href="/" className="logo">
            <img src="/logo.png" alt="SBTechEdge Logo" className="logo-img"/>
          </a>
          <nav>
            <ul className="nav-links">
              <li><a href="/">Home</a></li>
              <li><Link to="/about">About</Link></li>
              <li><a href="/courses">Courses</a></li>
              <li><a href="/materials">Study Materials</a></li>
              <li><a href="/contact">Contact</a></li>
            </ul>
          </nav>
        </div>
      </header>
    );
  }
  
  export default Header;
  